#include <iostream>

class ShellSort
{
public:
    ShellSort();
    ~ShellSort();
    void sort(int *array, int size);
    void print(int *array, int size);
};