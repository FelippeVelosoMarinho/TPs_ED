#ifndef _CONVERSAO_HPP_
#define _CONVERSAO_HPP_

#include <iostream>
#include "exceptions.hpp"
#include "pilha.hpp"

class Conversao
{
public:
    void converteInfToPos(char infixa[], char posfixa[]);
};

#endif